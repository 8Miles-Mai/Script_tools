#!/usr/local/bin/python

from gm_common import *



if __name__ == "__main__":

    curr_date=str(sys.argv[1]).split('-') 
    curr_day=curr_date[2]

# calc BL limit view times first day of the month
    log("update total " + str(total) + " records ")
#    if curr_day == '01' :
#        update_bl_status_to_db()
#    else :

