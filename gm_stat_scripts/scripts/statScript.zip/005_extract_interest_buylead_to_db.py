#!/usr/local/bin/python



from gm_common import *


def flush_to_db():
    log("flushing to stat db...")

    data=[]
    total=0
    
    for key in interest_counter :
        item = effect_log()
        item_arr=[]
        item_arr=interest_counter[key]
        item.comp_id=item_arr[0]
        item.ind_group_id=cdict[key]
        item.entity_source=STAT_TYPE.ENT_SRC_LC
        item.entity_id=item_arr[1]
        item.counter=item_arr[2]

        data.append(item)
        total=total+1
        
    year_id=get_curr_year_no()
    week_id=get_curr_week_no()
    stat_date=get_curr_date()
    stat_type=STAT_TYPE.BLY_CNT

    load_to_client_effect_table(year_id=year_id,
                week_id=week_id,
                stat_date=stat_date,
                stat_type=stat_type,
                data=data)

    log("insert total " + str(total) + " records ")
    return True


if __name__ == "__main__":

    # restore cache data
    sdict,cdict,udict=get_supplier_list() 
    
    # global variables 

    interest_counter = {}
    curr_date=sys.argv[1]

    oraSql="""
            select seller_comp_id, leaf_cat_id, count(0)
              from 
                  (select (select comp_id from web$users wu where wu.user_id=bns.user_id) buyer_comp_id
                          ,(select comp_id from web$users wu where wu.user_id=ibni.user_id) seller_comp_id
                          ,bns.need_id need_id
                          ,decode(bns.need_type,1,'web_bl','ts_bl') bl_type
                          ,ibni.create_time create_time
                          ,bnc.leaf_cat_id leaf_cat_id
                          ,DECODE (bns.status, -3, 'deleted', 0, 'new', 7, 'online', 13, 'offline', 'na') status
                     from im$buy_need_interests ibni
                          ,buyer$needs          bns
                          ,buyer$need_cats      bnc
                    where ibni.create_time > to_date('""" + curr_date + """','yyyy-mm-dd')  
                      and ibni.create_time < to_date('""" + curr_date + """', 'yyyy-mm-dd')+1  
                      and ibni.need_id=bns.need_id
                      and bns.need_id=bnc.need_id
                   )
             group by seller_comp_id,leaf_cat_id
            """

    oraConn=get_oracle_conn()
    oraCurr=oraConn.cursor()
    for oraRs in oraCurr.execute(oraSql):
        seller_comp_id=str(oraRs[0])
        leaf_cat_id=oraRs[1]
        counter=oraRs[2]

        item_arr=[]
        item_arr.append(seller_comp_id)
        item_arr.append(leaf_cat_id)
        item_arr.append(counter)

        # make sure we have ind_group_id
        if cdict.has_key(seller_comp_id):
            interest_counter[seller_comp_id]=item_arr

    oraConn.close()

    # At the end flush to db 
    flush_to_db()
